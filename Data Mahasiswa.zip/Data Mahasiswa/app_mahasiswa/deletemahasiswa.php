<?php

include "koneksi.php";
$nim = $_GET['nim'];

$sql = "DELETE FROM mahasiswa  WHERE nim ='$nim'";
	$query = mysqli_query($con,$sql);

	if($query) {
		header("Location: index.php?simpan=sukses");
	} else {
		header("Location: index.php?pesan=gagal");
	}
?>