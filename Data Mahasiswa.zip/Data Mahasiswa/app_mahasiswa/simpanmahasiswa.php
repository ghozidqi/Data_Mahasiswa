<?php
include "koneksi.php";

if (isset($_GET['simpan'])) {
	$nama = $_GET['nama'];
	$alamat = $_GET['alamat'];
	$sql = "INSERT INTO mahasiswa (nama, alamat) VALUES ('$nama','$alamat')";
	$query = mysqli_query($con,$sql);

	if($query) {
		header("Location: index.php?simpan=sukses");
	}

}else {
	header("Location: index.php?pesan=gagal");
}

  ?>