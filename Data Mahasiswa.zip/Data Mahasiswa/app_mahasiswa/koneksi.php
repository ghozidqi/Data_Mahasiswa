<?php

$severname ="localhost";
$username ="root";
$password ="";
$db_name ="db_mahasiswa";
$port ="3306";
$con =mysqli_connect($severname,$username,$password,$db_name);

//if ($con) {
//	echo "berhasil";
//}else{
//   echo "gagal";
//   }


 ?>