<?php

include "koneksi.php";

if (isset($_GET['update'])) {
	$nim = $_GET['nim'];
    $nama = $_GET['nama'];
	$alamat = $_GET['alamat'];

	$sql = "UPDATE mahasiswa SET nama = '$nama',alamat = '$alamat' WHERE nim ='$nim'";
	$query = mysqli_query($con,$sql);

	if($query) {
		header("Location: index.php?simpan=sukses");
	} else {
		echo "ada kesalahan";
	}

} else {
	header("Location: index.php?pesan=gagal");
}

?>
