<?php
include "koneksi.php";
$nim = $_GET['nim'];
$sql = "SELECT * FROM mahasiswa WHERE nim = '$nim'";
$query = mysqli_query($con,$sql);

 while ($mahasiswa = mysqli_fetch_array($query)) {

 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Edit Mahasiswa</title>
</head>
<body>

	<h1>Edit Mahasiswa</h1>
	<hr>

	<form action="updatemahasiswa.php" method="GET">
		<input type="hidden" name="nim" value="<?php echo $mahasiswa [0]?>">
		<label>Nama</label><br>
		<input type="text" name="nama"value="<?php echo $mahasiswa [1]; ?>"required><br></br>

		<label>Alamat</label><br>
		<input type="text" name="alamat"value="<?php echo $mahasiswa [2]; ?>"required><br></br>

		<input type="submit" name="update" value="Update">
	</form>

</body>
</html>
<?php
}
?>