<?php

include "koneksi.php";
$sql ="SELECT * FROM mahasiswa";
$query =mysqli_query($con, $sql);


?>

<!DOCTYPE html>
<html>
<head>
	<title>Data Mahasiswa</title>
   <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
   <h1>Data Mahasiswa</h1>
   <hr>

   <a href="tambahmahasiswa.php"><button class="tambah data">tambah data</button></a><br></br>
   <table border="" ="1">
   	<tr>
   		<th>NIM</th>
   		<th>Nama</th>
   		<th>Alamat</th>
   		<th class="edit">aksi</th>
   	</tr>
 <?php
 while ($mahasiswa = mysqli_fetch_array($query)) {
 	echo "<tr>";
 	echo "<td>" . $mahasiswa[0] . "</td>";
 	echo "<td>" . $mahasiswa[1] . "</td>";
 	echo "<td>" . $mahasiswa[2] . "</td>";
 	echo "<td class='edit'><a href='editmahasiswa.php?nim=$mahasiswa[0]'>Edit</a>

 	          <a href='deletemahasiswa.php?nim=$mahasiswa[0]'>Hapus</a></td>";
 	echo "</tr>";
 }
 ?>
   </table>

   <br>
   <button class="cetak"onclick="window.print()">Cetak</button>
</body>
</html>