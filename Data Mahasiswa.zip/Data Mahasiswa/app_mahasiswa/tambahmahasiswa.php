<!DOCTYPE html>
<html>
<head>
	<title>Tambah Mahasiswa</title>
</head>
<body>

	<h1>Tambah Mahasiswa</h1>
	<hr>

	<form action="simpanmahasiswa.php" method="GET">
		<label>Nama</label><br></br>
		<input type="text" name="nama"required><br>

		<label>Alamat</label><br></br>
		<input type="text" name="alamat"required><br>

		<input type="submit" name="simpan" value="Simpan">
	</form>

</body>
</html>